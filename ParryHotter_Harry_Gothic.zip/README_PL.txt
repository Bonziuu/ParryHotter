PARRY HOTTER — HARRY HP2 PC + WLASNE ANIMACJE ROZDZKI

Zawartosc: PH_HARRY.ASC, cztery TGA, projekty Blendera, podglady i raporty.
Dodatkowe PH_HARRY_CAST.MDS, PH_HARRY_CHARGE.ASC i PH_HARRY_RELEASE.ASC
stanowia kompletny zestaw autorskich animacji na 25 kosciach Gothica.
Przygotowanie ma 43 klatki, rzut 26 klatek, oba klipy 30 FPS. Pliki przechodza walidacje,
ponowny import do Blendera i probe instalacji na rzeczywistych zrodlach ModKitu.
To zrodla ASC/MDS; kompilacja animacji przez Gothic nie zostala wykonana.

INSTALACJA Z AKTUALNYM KODEM PROJEKTU
Umiesc ParryHotter_Harry_Gothic.zip obok INSTALUJ_PARRY_HOTTER.bat.
Albo: py -3 -m tools.import_harry_bundle --game "C:\Gry\Gothic" --bundle "ParryHotter_Harry_Gothic.zip"
Wymagane zrodla ModKitu Gothic.src, PC_Hero.d i HUMANS.MDS.
Nakladka zostaje przypisana tylko do PC_Hero. Wymagana NOWA GRA.
Nastepnie Reparse Scripts w GothicStarter_mod i przebudowa .mod z aktualna DLL.
DLL musi miec marker PH_BUILD_013_TEN_SLOTS_PROJECTILE_INPUT_CAST_ANIM.
Skrypt kompilacji Windows: tools/build_union.ps1 (MSVC2022/Win32).

GIF i obrazy to podglady Blendera, nie nagranie dzialania Gothica.
Natywna DLL i rozgrywka pozostaja niesprawdzone. Pobranie Windows SDK w chmurze
nadal wymaga zastosowania dostepu do download.visualstudio.microsoft.com.
Czary korzystaja z efektow Gothica. Pelny zestaw ruchow HP i ragdoll sa niedokonczone.
Szczegoly: docs/DEV-013.md w aktualnej paczce zrodel.

Oryginalny model: przeslane archiwum HP2 PC; pochodzenie i sumy w MANIFEST.json.
INFOmesh_original.txt pochodzi z tego archiwum. Referencja MDK nie jest dolaczona.
